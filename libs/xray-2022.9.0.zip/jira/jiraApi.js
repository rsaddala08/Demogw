const _ = require("lodash"),
    axios = require("axios").default,
    process = require("process"),
    logUtil = require("./../util/logUtilities.js"),
    jiraAPIUrl = process.env.JIRA_API_URL,
    jiraAuth = process.env.JIRA_API_USER + ":" + process.env.JIRA_API_TOKEN;

/**
 * Adds component to to specified PORT jiras
 */
async function updateJiraComponent(bodyData, jiraID) {
  const options = {
    method: "PUT",
    url: jiraAPIUrl + "/rest/api/3/issue/" + jiraID,
    headers: {
      "Authorization": `Basic ${Buffer.from(
          jiraAuth
      ).toString("base64")}`,
      "Accept": "application/json",
      "Content-Type": "application/json"
    },
    data: bodyData
  };
  try {
    const response = await axios(options);
    console.log(
        `Response: ${response.status} ${response.statusText} - component updated for ${jiraID}`
    );
    return response.data;
  } catch (error){
    logUtil.logHttpError(error);
  }
}

/**
 * returns jira ID by searching for its summary in the cloud rules project
 */
async function getJiraIdBySummary(bodyData, jiraSummary) {
  const options = {
    method: "POST",
    url: jiraAPIUrl + "/rest/api/3/search",
    headers: {
      "Authorization": `Basic ${Buffer.from(
          jiraAuth
      ).toString("base64")}`,
      "Accept": "application/json",
      "Content-Type": "application/json"
    },
    data: bodyData
  };
  let issueFound = true,
      issues = [];
  try {
    const response = await axios(options);
    if (response.data.issues.length === 0){
      issueFound = false;
      throw new Error("No tests found for " + jiraSummary);
    }else if (response.data.issues.length === 1){
      return response.data.issues["0"].key;
    }else {
      issueFound = false;
      _.each(response.data.issues, function (issue) {
        if (issue.fields.summary === jiraSummary){
          issueFound = true;
          issues.push(issue.key);
        }
      });
      if (!issueFound){
        throw new Error("More than one test found for " + jiraSummary);
      }else {
        if (issues.length === 1) {
          return issues[0];
        } else {
          issueFound = false;
          throw new Error("More than one test found for " + jiraSummary);
        }
      }
    }
  } catch (error){
      await logUtil.logHttpError(error);
  }

}

module.exports = {
  updateJiraComponent,
  getJiraIdBySummary
};



