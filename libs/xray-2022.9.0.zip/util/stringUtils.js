/*
 Utility to escape special characters in a string
 */
function escapeSpecialChars (string) {
    return string.replace(/[-.*+?^${}()|[\]\\]/g, '\\\\$&');
}

module.exports = {
    escapeSpecialChars
};